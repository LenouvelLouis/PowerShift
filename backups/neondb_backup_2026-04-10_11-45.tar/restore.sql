--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.8 (a48d9ca)
-- Dumped by pg_dump version 17.9 (Debian 17.9-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE neondb;
--
-- Name: neondb; Type: DATABASE; Schema: -; Owner: neondb_owner
--

CREATE DATABASE neondb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = builtin LOCALE = 'C.UTF-8' BUILTIN_LOCALE = 'C.UTF-8';


ALTER DATABASE neondb OWNER TO neondb_owner;

\unrestrict (null)
\connect neondb
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: neon_auth; Type: SCHEMA; Schema: -; Owner: neon_auth
--

CREATE SCHEMA neon_auth;


ALTER SCHEMA neon_auth OWNER TO neon_auth;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.account (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "accountId" text NOT NULL,
    "providerId" text NOT NULL,
    "userId" uuid NOT NULL,
    "accessToken" text,
    "refreshToken" text,
    "idToken" text,
    "accessTokenExpiresAt" timestamp with time zone,
    "refreshTokenExpiresAt" timestamp with time zone,
    scope text,
    password text,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE neon_auth.account OWNER TO neon_auth;

--
-- Name: invitation; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.invitation (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "organizationId" uuid NOT NULL,
    email text NOT NULL,
    role text,
    status text NOT NULL,
    "expiresAt" timestamp with time zone NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "inviterId" uuid NOT NULL
);


ALTER TABLE neon_auth.invitation OWNER TO neon_auth;

--
-- Name: jwks; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.jwks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "publicKey" text NOT NULL,
    "privateKey" text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "expiresAt" timestamp with time zone
);


ALTER TABLE neon_auth.jwks OWNER TO neon_auth;

--
-- Name: member; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.member (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "organizationId" uuid NOT NULL,
    "userId" uuid NOT NULL,
    role text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL
);


ALTER TABLE neon_auth.member OWNER TO neon_auth;

--
-- Name: organization; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.organization (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    logo text,
    "createdAt" timestamp with time zone NOT NULL,
    metadata text
);


ALTER TABLE neon_auth.organization OWNER TO neon_auth;

--
-- Name: project_config; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.project_config (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    endpoint_id text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    trusted_origins jsonb NOT NULL,
    social_providers jsonb NOT NULL,
    email_provider jsonb,
    email_and_password jsonb,
    allow_localhost boolean NOT NULL,
    plugin_configs jsonb,
    webhook_config jsonb
);


ALTER TABLE neon_auth.project_config OWNER TO neon_auth;

--
-- Name: session; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.session (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "expiresAt" timestamp with time zone NOT NULL,
    token text NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "ipAddress" text,
    "userAgent" text,
    "userId" uuid NOT NULL,
    "impersonatedBy" text,
    "activeOrganizationId" text
);


ALTER TABLE neon_auth.session OWNER TO neon_auth;

--
-- Name: user; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth."user" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "emailVerified" boolean NOT NULL,
    image text,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    role text,
    banned boolean,
    "banReason" text,
    "banExpires" timestamp with time zone
);


ALTER TABLE neon_auth."user" OWNER TO neon_auth;

--
-- Name: verification; Type: TABLE; Schema: neon_auth; Owner: neon_auth
--

CREATE TABLE neon_auth.verification (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    identifier text NOT NULL,
    value text NOT NULL,
    "expiresAt" timestamp with time zone NOT NULL,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE neon_auth.verification OWNER TO neon_auth;

--
-- Name: asset_parameters; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.asset_parameters (
    id uuid NOT NULL,
    asset_id uuid NOT NULL,
    asset_type character varying NOT NULL,
    params json NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.asset_parameters OWNER TO neondb_owner;

--
-- Name: demands; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.demands (
    id uuid NOT NULL,
    name character varying NOT NULL,
    type character varying NOT NULL,
    load_mw double precision NOT NULL,
    status character varying NOT NULL,
    unit character varying NOT NULL,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.demands OWNER TO neondb_owner;

--
-- Name: network_components; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.network_components (
    id uuid NOT NULL,
    name character varying NOT NULL,
    type character varying NOT NULL,
    voltage_kv double precision NOT NULL,
    capacity_mva double precision,
    losses_kw double precision,
    voltage_hv_kv double precision,
    voltage_lv_kv double precision,
    length_km double precision,
    resistance_ohm_per_km double precision,
    reactance_ohm_per_km double precision,
    status character varying NOT NULL,
    unit character varying NOT NULL,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.network_components OWNER TO neondb_owner;

--
-- Name: pv_hourly; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.pv_hourly (
    "time" text,
    t2m real,
    ws10m real,
    p_west real,
    "g(i)_west" real,
    h_sun_west real,
    int_west real,
    p_east real,
    "g(i)_east" real,
    h_sun_east real,
    int_east real
);


ALTER TABLE public.pv_hourly OWNER TO neondb_owner;

--
-- Name: simulation_requests; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.simulation_requests (
    id uuid NOT NULL,
    snapshot_hours integer NOT NULL,
    solver character varying NOT NULL,
    pypsa_params json,
    supply_ids json NOT NULL,
    demand_ids json NOT NULL,
    network_ids json NOT NULL,
    created_at timestamp without time zone NOT NULL,
    hourly_load_overrides jsonb,
    optimization_objective character varying(32) DEFAULT 'min_cost'::character varying NOT NULL,
    start_date date,
    end_date date,
    asset_overrides jsonb,
    overrides jsonb,
    name character varying
);


ALTER TABLE public.simulation_requests OWNER TO neondb_owner;

--
-- Name: simulation_results; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.simulation_results (
    id uuid NOT NULL,
    request_id uuid NOT NULL,
    status character varying NOT NULL,
    total_supply_mwh double precision,
    total_demand_mwh double precision,
    balance_mwh double precision,
    objective_value double precision,
    result_json json,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.simulation_results OWNER TO neondb_owner;

--
-- Name: supplies; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.supplies (
    id uuid NOT NULL,
    name character varying NOT NULL,
    type character varying NOT NULL,
    capacity_mw double precision NOT NULL,
    efficiency double precision NOT NULL,
    status character varying NOT NULL,
    unit character varying NOT NULL,
    description character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.supplies OWNER TO neondb_owner;

--
-- Name: weather_profile; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.weather_profile (
    "timestamp" timestamp with time zone NOT NULL,
    wind_speed_ms double precision,
    wind_dir_deg double precision,
    wind_gust_ms double precision,
    temperature_c double precision,
    air_pressure_hpa double precision,
    humidity_pct double precision,
    radiation_wm2 double precision,
    sunshine_min double precision
);


ALTER TABLE public.weather_profile OWNER TO neondb_owner;

--
-- Name: wind_measurement; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.wind_measurement (
    id uuid NOT NULL,
    station_code character varying NOT NULL,
    station_name character varying NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    wind_speed_ms double precision,
    wind_direction_deg double precision,
    temperature_c double precision,
    air_pressure_hpa double precision,
    latitude double precision,
    longitude double precision
);


ALTER TABLE public.wind_measurement OWNER TO neondb_owner;

--
-- Data for Name: account; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.account (id, "accountId", "providerId", "userId", "accessToken", "refreshToken", "idToken", "accessTokenExpiresAt", "refreshTokenExpiresAt", scope, password, "createdAt", "updatedAt") FROM stdin;
\.
COPY neon_auth.account (id, "accountId", "providerId", "userId", "accessToken", "refreshToken", "idToken", "accessTokenExpiresAt", "refreshTokenExpiresAt", scope, password, "createdAt", "updatedAt") FROM '$$PATH$$/3545.dat';

--
-- Data for Name: invitation; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.invitation (id, "organizationId", email, role, status, "expiresAt", "createdAt", "inviterId") FROM stdin;
\.
COPY neon_auth.invitation (id, "organizationId", email, role, status, "expiresAt", "createdAt", "inviterId") FROM '$$PATH$$/3550.dat';

--
-- Data for Name: jwks; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.jwks (id, "publicKey", "privateKey", "createdAt", "expiresAt") FROM stdin;
\.
COPY neon_auth.jwks (id, "publicKey", "privateKey", "createdAt", "expiresAt") FROM '$$PATH$$/3547.dat';

--
-- Data for Name: member; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.member (id, "organizationId", "userId", role, "createdAt") FROM stdin;
\.
COPY neon_auth.member (id, "organizationId", "userId", role, "createdAt") FROM '$$PATH$$/3549.dat';

--
-- Data for Name: organization; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.organization (id, name, slug, logo, "createdAt", metadata) FROM stdin;
\.
COPY neon_auth.organization (id, name, slug, logo, "createdAt", metadata) FROM '$$PATH$$/3548.dat';

--
-- Data for Name: project_config; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.project_config (id, name, endpoint_id, created_at, updated_at, trusted_origins, social_providers, email_provider, email_and_password, allow_localhost, plugin_configs, webhook_config) FROM stdin;
\.
COPY neon_auth.project_config (id, name, endpoint_id, created_at, updated_at, trusted_origins, social_providers, email_provider, email_and_password, allow_localhost, plugin_configs, webhook_config) FROM '$$PATH$$/3551.dat';

--
-- Data for Name: session; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.session (id, "expiresAt", token, "createdAt", "updatedAt", "ipAddress", "userAgent", "userId", "impersonatedBy", "activeOrganizationId") FROM stdin;
\.
COPY neon_auth.session (id, "expiresAt", token, "createdAt", "updatedAt", "ipAddress", "userAgent", "userId", "impersonatedBy", "activeOrganizationId") FROM '$$PATH$$/3544.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth."user" (id, name, email, "emailVerified", image, "createdAt", "updatedAt", role, banned, "banReason", "banExpires") FROM stdin;
\.
COPY neon_auth."user" (id, name, email, "emailVerified", image, "createdAt", "updatedAt", role, banned, "banReason", "banExpires") FROM '$$PATH$$/3543.dat';

--
-- Data for Name: verification; Type: TABLE DATA; Schema: neon_auth; Owner: neon_auth
--

COPY neon_auth.verification (id, identifier, value, "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.
COPY neon_auth.verification (id, identifier, value, "expiresAt", "createdAt", "updatedAt") FROM '$$PATH$$/3546.dat';

--
-- Data for Name: asset_parameters; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.asset_parameters (id, asset_id, asset_type, params, created_at, updated_at) FROM stdin;
\.
COPY public.asset_parameters (id, asset_id, asset_type, params, created_at, updated_at) FROM '$$PATH$$/3552.dat';

--
-- Data for Name: demands; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.demands (id, name, type, load_mw, status, unit, description, created_at, updated_at) FROM stdin;
\.
COPY public.demands (id, name, type, load_mw, status, unit, description, created_at, updated_at) FROM '$$PATH$$/3553.dat';

--
-- Data for Name: network_components; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.network_components (id, name, type, voltage_kv, capacity_mva, losses_kw, voltage_hv_kv, voltage_lv_kv, length_km, resistance_ohm_per_km, reactance_ohm_per_km, status, unit, description, created_at, updated_at) FROM stdin;
\.
COPY public.network_components (id, name, type, voltage_kv, capacity_mva, losses_kw, voltage_hv_kv, voltage_lv_kv, length_km, resistance_ohm_per_km, reactance_ohm_per_km, status, unit, description, created_at, updated_at) FROM '$$PATH$$/3554.dat';

--
-- Data for Name: pv_hourly; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.pv_hourly ("time", t2m, ws10m, p_west, "g(i)_west", h_sun_west, int_west, p_east, "g(i)_east", h_sun_east, int_east) FROM stdin;
\.
COPY public.pv_hourly ("time", t2m, ws10m, p_west, "g(i)_west", h_sun_west, int_west, p_east, "g(i)_east", h_sun_east, int_east) FROM '$$PATH$$/3558.dat';

--
-- Data for Name: simulation_requests; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.simulation_requests (id, snapshot_hours, solver, pypsa_params, supply_ids, demand_ids, network_ids, created_at, hourly_load_overrides, optimization_objective, start_date, end_date, asset_overrides, overrides, name) FROM stdin;
\.
COPY public.simulation_requests (id, snapshot_hours, solver, pypsa_params, supply_ids, demand_ids, network_ids, created_at, hourly_load_overrides, optimization_objective, start_date, end_date, asset_overrides, overrides, name) FROM '$$PATH$$/3555.dat';

--
-- Data for Name: simulation_results; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.simulation_results (id, request_id, status, total_supply_mwh, total_demand_mwh, balance_mwh, objective_value, result_json, created_at) FROM stdin;
\.
COPY public.simulation_results (id, request_id, status, total_supply_mwh, total_demand_mwh, balance_mwh, objective_value, result_json, created_at) FROM '$$PATH$$/3557.dat';

--
-- Data for Name: supplies; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.supplies (id, name, type, capacity_mw, efficiency, status, unit, description, created_at, updated_at) FROM stdin;
\.
COPY public.supplies (id, name, type, capacity_mw, efficiency, status, unit, description, created_at, updated_at) FROM '$$PATH$$/3556.dat';

--
-- Data for Name: weather_profile; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.weather_profile ("timestamp", wind_speed_ms, wind_dir_deg, wind_gust_ms, temperature_c, air_pressure_hpa, humidity_pct, radiation_wm2, sunshine_min) FROM stdin;
\.
COPY public.weather_profile ("timestamp", wind_speed_ms, wind_dir_deg, wind_gust_ms, temperature_c, air_pressure_hpa, humidity_pct, radiation_wm2, sunshine_min) FROM '$$PATH$$/3560.dat';

--
-- Data for Name: wind_measurement; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.wind_measurement (id, station_code, station_name, "timestamp", wind_speed_ms, wind_direction_deg, temperature_c, air_pressure_hpa, latitude, longitude) FROM stdin;
\.
COPY public.wind_measurement (id, station_code, station_name, "timestamp", wind_speed_ms, wind_direction_deg, temperature_c, air_pressure_hpa, latitude, longitude) FROM '$$PATH$$/3559.dat';

--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (id);


--
-- Name: invitation invitation_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.invitation
    ADD CONSTRAINT invitation_pkey PRIMARY KEY (id);


--
-- Name: jwks jwks_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.jwks
    ADD CONSTRAINT jwks_pkey PRIMARY KEY (id);


--
-- Name: member member_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.member
    ADD CONSTRAINT member_pkey PRIMARY KEY (id);


--
-- Name: organization organization_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.organization
    ADD CONSTRAINT organization_pkey PRIMARY KEY (id);


--
-- Name: organization organization_slug_key; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.organization
    ADD CONSTRAINT organization_slug_key UNIQUE (slug);


--
-- Name: project_config project_config_endpoint_id_key; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.project_config
    ADD CONSTRAINT project_config_endpoint_id_key UNIQUE (endpoint_id);


--
-- Name: project_config project_config_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.project_config
    ADD CONSTRAINT project_config_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: session session_token_key; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.session
    ADD CONSTRAINT session_token_key UNIQUE (token);


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: verification verification_pkey; Type: CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.verification
    ADD CONSTRAINT verification_pkey PRIMARY KEY (id);


--
-- Name: asset_parameters asset_parameters_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.asset_parameters
    ADD CONSTRAINT asset_parameters_pkey PRIMARY KEY (id);


--
-- Name: demands demands_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.demands
    ADD CONSTRAINT demands_pkey PRIMARY KEY (id);


--
-- Name: network_components network_components_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.network_components
    ADD CONSTRAINT network_components_pkey PRIMARY KEY (id);


--
-- Name: simulation_requests simulation_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.simulation_requests
    ADD CONSTRAINT simulation_requests_pkey PRIMARY KEY (id);


--
-- Name: simulation_results simulation_results_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.simulation_results
    ADD CONSTRAINT simulation_results_pkey PRIMARY KEY (id);


--
-- Name: supplies supplies_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.supplies
    ADD CONSTRAINT supplies_pkey PRIMARY KEY (id);


--
-- Name: wind_measurement uq_wind_measurement_station_ts; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wind_measurement
    ADD CONSTRAINT uq_wind_measurement_station_ts UNIQUE (station_code, "timestamp");


--
-- Name: weather_profile weather_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.weather_profile
    ADD CONSTRAINT weather_profile_pkey PRIMARY KEY ("timestamp");


--
-- Name: wind_measurement wind_measurement_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.wind_measurement
    ADD CONSTRAINT wind_measurement_pkey PRIMARY KEY (id);


--
-- Name: account_userId_idx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE INDEX "account_userId_idx" ON neon_auth.account USING btree ("userId");


--
-- Name: invitation_email_idx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE INDEX invitation_email_idx ON neon_auth.invitation USING btree (email);


--
-- Name: invitation_organizationId_idx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE INDEX "invitation_organizationId_idx" ON neon_auth.invitation USING btree ("organizationId");


--
-- Name: member_organizationId_idx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE INDEX "member_organizationId_idx" ON neon_auth.member USING btree ("organizationId");


--
-- Name: member_userId_idx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE INDEX "member_userId_idx" ON neon_auth.member USING btree ("userId");


--
-- Name: organization_slug_uidx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE UNIQUE INDEX organization_slug_uidx ON neon_auth.organization USING btree (slug);


--
-- Name: session_userId_idx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE INDEX "session_userId_idx" ON neon_auth.session USING btree ("userId");


--
-- Name: verification_identifier_idx; Type: INDEX; Schema: neon_auth; Owner: neon_auth
--

CREATE INDEX verification_identifier_idx ON neon_auth.verification USING btree (identifier);


--
-- Name: idx_pv_hourly_time; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_pv_hourly_time ON public.pv_hourly USING btree ("time");


--
-- Name: ix_weather_profile_timestamp; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_weather_profile_timestamp ON public.weather_profile USING btree ("timestamp");


--
-- Name: ix_wind_measurement_station_code; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_wind_measurement_station_code ON public.wind_measurement USING btree (station_code);


--
-- Name: ix_wind_measurement_station_ts; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_wind_measurement_station_ts ON public.wind_measurement USING btree (station_code, "timestamp");


--
-- Name: ix_wind_measurement_timestamp; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_wind_measurement_timestamp ON public.wind_measurement USING btree ("timestamp");


--
-- Name: account account_userId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.account
    ADD CONSTRAINT "account_userId_fkey" FOREIGN KEY ("userId") REFERENCES neon_auth."user"(id) ON DELETE CASCADE;


--
-- Name: invitation invitation_inviterId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.invitation
    ADD CONSTRAINT "invitation_inviterId_fkey" FOREIGN KEY ("inviterId") REFERENCES neon_auth."user"(id) ON DELETE CASCADE;


--
-- Name: invitation invitation_organizationId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.invitation
    ADD CONSTRAINT "invitation_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES neon_auth.organization(id) ON DELETE CASCADE;


--
-- Name: member member_organizationId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.member
    ADD CONSTRAINT "member_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES neon_auth.organization(id) ON DELETE CASCADE;


--
-- Name: member member_userId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.member
    ADD CONSTRAINT "member_userId_fkey" FOREIGN KEY ("userId") REFERENCES neon_auth."user"(id) ON DELETE CASCADE;


--
-- Name: session session_userId_fkey; Type: FK CONSTRAINT; Schema: neon_auth; Owner: neon_auth
--

ALTER TABLE ONLY neon_auth.session
    ADD CONSTRAINT "session_userId_fkey" FOREIGN KEY ("userId") REFERENCES neon_auth."user"(id) ON DELETE CASCADE;


--
-- Name: simulation_results simulation_results_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.simulation_results
    ADD CONSTRAINT simulation_results_request_id_fkey FOREIGN KEY (request_id) REFERENCES public.simulation_requests(id);


--
-- Name: DATABASE neondb; Type: ACL; Schema: -; Owner: neondb_owner
--

GRANT ALL ON DATABASE neondb TO neon_superuser;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

